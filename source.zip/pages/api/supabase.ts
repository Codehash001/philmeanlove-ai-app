// pages/api/ingest-files.ts

import type { NextApiRequest, NextApiResponse } from 'next';
import fs from 'fs';
import path from 'path';
import { supabase } from '../../utils/supabase'


export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).end(); // Method Not Allowed
  }

  const docsPath = path.join(process.cwd(), 'public', 'docs');
  const files = fs.readdirSync(docsPath);
  console.log(files)

  try {
    const { data, error } = await supabase
      .from('files')
      .update({ ingestedFiles: files }, { returning: 'minimal' });

    if (error) {
      throw new Error(error.message);
    }

    return res.status(200).json({ message: 'Files ingested successfully.' });
  } catch (error) {
    return res.status(500).json({ error: 'error.message '});
  }
}
